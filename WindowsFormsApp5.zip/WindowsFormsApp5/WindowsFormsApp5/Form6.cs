﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pCBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.pCBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.st17DataSet1);

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "st17DataSet11.makerProd". При необходимости она может быть перемещена или удалена.
            this.makerProdTableAdapter.Fill(this.st17DataSet11.makerProd);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "st17DataSet1.PC". При необходимости она может быть перемещена или удалена.
            this.pCTableAdapter.Fill(this.st17DataSet1.PC);

        }

        private void pCBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        private System.Windows.Forms.DataGridViewColumn Col;
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Col = new System.Windows.Forms.DataGridViewColumn();
            switch (listBox1.SelectedIndex)
            {
                case 0:
                    Col = dataGridViewTextBoxColumn2;
                    break;
                case 1:
                    Col = dataGridViewTextBoxColumn4;
                    break;
                case 2:
                    Col = dataGridViewTextBoxColumn6;
                    break;
            }
            if (radioButton1.Checked)
                makerProdDataGridView.Sort(Col, System.ComponentModel.ListSortDirection.Ascending);
            else
                makerProdDataGridView.Sort(Col, System.ComponentModel.ListSortDirection.Descending);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            makerProdBindingSource.Filter = "Name='" + comboBox1.Text + "'";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            makerProdBindingSource.Filter = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            for (int i=0; i<makerProdDataGridView.ColumnCount-1;i++)
            {
                for (int j=0; j<makerProdDataGridView.RowCount-1;j++)
                {
                    makerProdDataGridView[i, j].Style.BackColor = Color.White;
                    makerProdDataGridView[i, j].Style.ForeColor = Color.Black;
                }
            }
            for(int i=0;i<makerProdDataGridView.ColumnCount-1;i++)
            {
                for (int j = 0; j < makerProdDataGridView.RowCount - 1; j++)
                {
                    if (makerProdDataGridView[i, j].Value.ToString().IndexOf(textBox1.Text) != -1)

                    {
                        makerProdDataGridView[i, j].Style.BackColor = Color.AliceBlue;
                        makerProdDataGridView[i, j].Style.ForeColor = Color.Blue;
                    }
                }

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
