﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        private Form2 Form2;
        private Form3 Form3;
        private Form4 Form4;
        private Form5 Form5;
        private Form6 Form6;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 = new Form4();
            this.Hide();
            Form4.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 = new Form5();
            this.Hide();
            Form5.ShowDialog();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 = new Form2();
            this.Hide();
            Form2.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 = new Form3();
            this.Hide();
            Form3.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form6 = new Form6();
            this.Hide();
            Form6.ShowDialog();
        }
    }
}
